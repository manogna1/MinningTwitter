### Description
#### Find whether factors like Positive Sentiment analysis and lexical diversity effects favorite count or not?
#### Platform: Twitter

#### Modules Required: 
Twitter API,Tweepy,Pickle,Counter,Text table,Matplotlib,numpy

#### Analysis Techniques:
Graph Algorithms

#### Data Visualization:
I will visualize data and would like to display data in a table.
Graph that displays and explains relationship between Favorite count and Positive analysis.


#### Tweepy
Using tweepy
Tweepy supports accessing Twitter via Basic Authentication and the newer method, OAuth. Twitter has stopped accepting Basic Authentication so OAuth is now the only way to use the Twitter API.

    pip install tweepy



    

